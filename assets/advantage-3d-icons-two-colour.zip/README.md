# Advantage 3D category icons – two-colour

Eight icons, one per procurement area, with Ultramarine accents. SVG for design and the web, PNG at 1024 px, transparent background.

Rules: one angle, light from the left, everything faces right, a soft footprint shadow, no tile behind the icon.
